package table

type Table struct {
	TableName   string
	TableSchema string
	TableOwner  string
}
