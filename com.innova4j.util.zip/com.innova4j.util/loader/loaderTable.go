// db.go
package main

import (
	"bufio"
	"bytes"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"os"
	"os/exec"
	"regexp"
	"strings"

	"com.innova4j.util/fileStruct"
	"com.innova4j.util/table"

	_ "github.com/lib/pq"
)

var camelingRegex = regexp.MustCompile("[0-9A-Za-z]+")

func main() {

	if db, err := getDB("postgres://bookcore:9d9dj3j3_..lk2h3@192.168.0.217/bookcore?sslmode=disable"); err != nil {
		//if db, err := getDB("user=bookcore password=9d9dj3j3_..lk2h3 dbname=bookcore sslmode=disable"); err != nil {

		fmt.Println("Ocurrio un error", err.Error())
	} else {
		err = db.Ping()
		if err != nil {
			fmt.Println("Error: Could not establish a connection with the database")
		}
		tables := []table.Table{}
		fieldsMap := make(map[string]string)
		if true {
			tables, fieldsMap = GetTablesFromFile(db, "tableList/tableList.txt")
		} else {
			tables = GetAllTables(db)
		}
		queryTables(db, tables, fieldsMap)
	}
}

func GetTablesFromFile(pDb *sql.DB, pPath string) ([]table.Table, map[string]string) {

	file, errror := os.Open(pPath)
	if errror != nil {
		fmt.Println(errror)
		return nil, nil
	}

	defer file.Close()

	var lines []string

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		lines = append(lines, strings.ToLower(scanner.Text()))
	}

	var tablesName bytes.Buffer

	fieldsMap := make(map[string]string)

	var listOfTables []string

	for i, line := range lines {
		tablesName.WriteString("'")
		splitStr := strings.Split(line, ";")
		fieldsMap[strings.ToLower(splitStr[0])] = splitStr[1]
		listOfTables = append(listOfTables, splitStr[0])
		tablesName.WriteString(splitStr[0])
		tablesName.WriteString("'")
		if i < len(lines)-1 {
			tablesName.WriteString(", ")
		}
	}

	var builderQuery bytes.Buffer
	builderQuery.WriteString("SELECT table_name, table_catalog, table_schema FROM INFORMATION_SCHEMA.TABLES WHERE table_schema = 'public' ")
	builderQuery.WriteString("AND table_name IN (")
	builderQuery.WriteString(tablesName.String())
	builderQuery.WriteString(")")
	builderQuery.WriteString("order by table_name")

	queryStmt, err := pDb.Prepare(builderQuery.String())

	if err != nil {
		fmt.Println(err)
	}
	tables := []table.Table{}
	rows, _ := queryStmt.Query()

	for rows.Next() {
		tableStruct := new(table.Table)
		var tableName string
		var tableSchema string
		var tableOwner string

		rows.Scan(&tableName, &tableSchema, &tableOwner)

		tableStruct.TableName = tableName
		tableStruct.TableSchema = tableSchema
		tableStruct.TableOwner = tableOwner
		tables = append(tables, *tableStruct)
	}

	missingTables := GetMissingTables(listOfTables, tables)
	missing := ShowMissingTables(missingTables)

	if missing {
		fmt.Println(builderQuery.String())
	}

	return tables, fieldsMap
}

/**
 * Metodo encargado de mostrar en consola las tablas que no se encontraron en BBDD.
 */
func ShowMissingTables(pMissingTables []string) bool {
	missing := false
	if len(pMissingTables) > 0 {
		fmt.Println("Las tablas que no se encontraron en BBDD fueron: ")
		missing = true
	}
	for _, table := range pMissingTables {
		fmt.Println(table)
	}
	return missing
}

/**
 * Metodo encargado de mostrar en consola los campos que no se encontraron en BBDD para cierta tabla.
 */
func ShowMissingFields(pMissingFields []string, pTable string) bool {
	missing := false
	if len(pMissingFields) > 0 {
		fmt.Printf("Los campos que no se encontraron para la tabla %v en BBDD fueron: ", pTable)
		fmt.Println(len(pMissingFields))
		missing = true
	}
	for _, field := range pMissingFields {
		fmt.Println(field)
	}
	return missing
}

/**
 * Metodo encargado de obtener la lista de tablas no encontradas en BBDD que se encuentran en el archivo.
 */
func GetMissingTables(pListFromFile []string, pTablesGetFromBBDD []table.Table) []string {
	missingTables := []string{}
	for _, tableFromFile := range pListFromFile {
		exist := false
		for _, tableFromBBDD := range pTablesGetFromBBDD {
			if strings.ToLower(tableFromBBDD.TableName) == strings.ToLower(tableFromFile) {
				exist = true
				break
			}
		}
		if !exist {
			missingTables = append(missingTables, tableFromFile)
		}
	}

	return missingTables
}

/**
 * Metodo encargado de obtener todas las tablas del schema Public de la BBDD.
 */
func GetAllTables(pDb *sql.DB) []table.Table {
	queryStmt, err := pDb.Prepare("SELECT table_name, table_catalog, table_schema FROM INFORMATION_SCHEMA.TABLES where table_schema = 'public' order by table_name")
	if err != nil {
		fmt.Println(err)
	}
	tables := []table.Table{}
	rows, _ := queryStmt.Query()

	for rows.Next() {
		tableStruct := new(table.Table)
		var tableName string
		var tableSchema string
		var tableOwner string
		rows.Scan(&tableName, &tableSchema, &tableOwner)
		//fmt.Println("Table Name | Table Schema | Table Owner |")
		//fmt.Printf("%v | %v | %v | \n", tableName, tableSchema, tableOwner)
		//fmt.Println("\n")
		tableStruct.TableName = tableName
		tableStruct.TableSchema = tableSchema
		tableStruct.TableOwner = tableOwner
		tables = append(tables, *tableStruct)
	}
	return tables
}

/**
 * Metodo encargado de realizar la consulta para cada tabla extraida anteriormente.
 */
func queryTables(pDb *sql.DB, pTables []table.Table, pFieldMap map[string]string) {

	for _, tableStruct := range pTables {

		builderQuery := bytes.Buffer{}
		builderQuery.WriteString("SELECT column_name, data_type, character_maximum_length, is_nullable FROM INFORMATION_SCHEMA.COLUMNS where table_name = '")
		builderQuery.WriteString(tableStruct.TableName)
		builderQuery.WriteString("'")
		//fmt.Println(builderQuery.String())
		queryStmtForTable, errs := pDb.Prepare(builderQuery.String())
		if errs != nil {
			fmt.Println(errs)
		}

		rows, _ := queryStmtForTable.Query()

		message := new(fileStruct.Message)
		entity := new(fileStruct.Entity)

		builderClassName := bytes.Buffer{}

		builderClassName.WriteString(strings.Title(CamelCase(tableStruct.TableName)))
		builderClassName.WriteString("CO")

		entity.Classname = builderClassName.String()
		entity.Tablename = strings.ToUpper(tableStruct.TableName)
		entity.Owner = tableStruct.TableOwner
		// Execute Command
		cmd := exec.Command("capnp", "id")
		var out bytes.Buffer
		cmd.Stdout = &out
		errror := cmd.Run()
		if errror != nil {
			fmt.Println(errror)
		}
		//fmt.Printf("ID CAPNP: %q\n", out.String())
		entity.Key = strings.Replace(out.String(), "\n", "", 1)
		entity.Attributes = []fileStruct.Attribute{}

		message.Entities = []fileStruct.Entity{}

		columnFilter := pFieldMap[strings.ToLower(entity.Tablename)]
		columns := strings.Split(columnFilter, ",")

		var columnBD bytes.Buffer
		columnBD.WriteString(",")

		for rows.Next() {
			var columnName string
			var dataType string
			var characterMaximumLength *int
			var isNullable string
			rows.Scan(&columnName, &dataType, &characterMaximumLength, &isNullable)

			columnBD.WriteString(strings.ToLower(columnName))
			columnBD.WriteString(",")
			//fmt.Println("Column Name | Data Type | Character Maximum Length | Is Nullable |")
			/*charLeng := 0
			if characterMaximumLength != nil {
				charLeng = *characterMaximumLength
			}*/
			//fmt.Printf("%v | %v | %v | %v | \n", columnName, dataType, charLeng, isNullable)
			//fmt.Println("\n")
			var columnNameToSearch bytes.Buffer
			columnNameToSearch.WriteString(columnName)
			columnNameToSearch.WriteString(",")
			if strings.Contains(columnFilter, columnNameToSearch.String()) {
				attribute := new(fileStruct.Attribute)
				attribute.Name = CamelCase(columnName)
				attribute.Namedb = strings.ToLower(columnName)
				attribute.Types = validateType(dataType)
				attribute.Nullable = validateNullableField(isNullable)
				if attribute.Nullable == "true" && attribute.Types == "int32" {
					attribute.Types = "int64"
				}
				if attribute.Name == "id" {
					attribute.PrimaryKey = "true"
				} else {
					attribute.PrimaryKey = "false"
				}

				entity.Attributes = append(entity.Attributes, *attribute)
				entity.Dependencies = []string{}
			}
		}

		missingFields := []string{}

		for _, column := range columns {
			var columnCompare bytes.Buffer
			columnCompare.WriteString(column)
			columnCompare.WriteString(",")
			if !strings.Contains(columnBD.String(), columnCompare.String()) {
				missingFields = append(missingFields, strings.ToLower(column))
			}
		}

		ShowMissingFields(missingFields, entity.Tablename)

		message.Entities = append(message.Entities, *entity)
		createFile(builderClassName.String(), message)

		createFileWithSelects(entity.Tablename, missingFields, pFieldMap)

	}

	fmt.Println("Finish!!")
}

/**
 * Metodo encargado de crear un archivo con los queries genericos.
 */
func createFileWithSelects(pTableName string, pMissingFields []string, pFieldMap map[string]string) {
	builderFileName := bytes.Buffer{}
	out := bytes.Buffer{}

	row := pFieldMap[strings.ToLower(pTableName)]
	selectQuery := strings.ToLower(row)
	countWordsRepeat := 0
	if len(pMissingFields) > 0 {
		for _, missingField := range pMissingFields {
			selectQuery, countWordsRepeat = processQuery(selectQuery, missingField)
		}
	}
	columns := strings.Split(selectQuery, ",")
	for _, column := range columns {
		selectQuery, countWordsRepeat = processQuery(selectQuery, column)
	}

	countWords := strings.Count(selectQuery, "--")
	//fmt.Println("countWords-->", countWords)
	selectQuery = strings.Replace(selectQuery, "--", "", 1)
	//fmt.Println("selectQuery-->", selectQuery)
	selectQuery = strings.Replace(selectQuery, "--", ", ", countWords-1)
	//fmt.Println("selectQuery-->", selectQuery)
	selectQuery = strings.Replace(selectQuery, ", ,", ",", countWordsRepeat)

	query := bytes.Buffer{}

	query.WriteString("SELECT ")
	query.WriteString(strings.ToUpper(selectQuery))
	query.WriteString(" FROM ")
	query.WriteString(strings.ToUpper(pTableName))

	out.WriteString(strings.Replace(query.String(), ",  FROM", " FROM", 1))

	builderFileName.WriteString("queries/")
	builderFileName.WriteString(pTableName)
	builderFileName.WriteString(".txt")
	errror := ioutil.WriteFile(builderFileName.String(), out.Bytes(), 0644)
	if errror != nil {
		fmt.Println(errror)
	}
}

func processQuery(pSelectQuery string, pColumn string) (string, int) {
	countComas := strings.Count(pSelectQuery, ",")
	pSelectQuery = strings.Replace(pSelectQuery, ",", "--", countComas)
	buildSearch := bytes.Buffer{}
	buildSearch.WriteString("-")
	buildSearch.WriteString(strings.ToLower(pColumn))
	buildSearch.WriteString("-")

	buildQuerySearch := bytes.Buffer{}
	buildQuerySearch.WriteString("--")
	buildQuerySearch.WriteString(pSelectQuery)
	//fmt.Println("COLUMN-->", pColumn)
	//fmt.Println("buildSearch.String()-->", buildSearch.String())
	//fmt.Println("buildQuerySearch.String()-->", buildQuerySearch.String())
	countWordsRepeat := strings.Count(buildQuerySearch.String(), buildSearch.String())
	//fmt.Println("countWordsRepeat-->", countWordsRepeat)
	//fmt.Println(pTableName, "--->", buildQuerySearch.String())
	if countWordsRepeat > 1 {
		pSelectQuery = strings.Replace(buildQuerySearch.String(), buildSearch.String(), "--", countWordsRepeat-1)
	}
	return pSelectQuery, countWordsRepeat
}

/**
 * Metodo encargado de crear los archivos por nombre de la tabla.
 */
func createFile(pClassName string, pMessage *fileStruct.Message) {
	builderFileName := bytes.Buffer{}
	b, _ := json.Marshal(pMessage)
	var out bytes.Buffer
	json.Indent(&out, b, "", "\t")
	builderFileName.WriteString("result/")
	builderFileName.WriteString(pClassName)
	builderFileName.WriteString(".json")
	errror := ioutil.WriteFile(builderFileName.String(), out.Bytes(), 0644)
	if errror != nil {
		fmt.Println(errror)
	}
}

/**
*	Metodo encargado de validar los tipos provinientes de la BBDD
*	y parsearlos a los debidos tipos en Go.
 */
func validateType(pEntryType string) string {
	if strings.Contains(pEntryType, "integer") || strings.Contains(pEntryType, "serial") {
		return "int32"
	}
	if strings.Contains(pEntryType, "character") || strings.Contains(pEntryType, "text") || strings.Contains(pEntryType, "json") {
		return "string"
	}
	if strings.Contains(pEntryType, "boolean") {
		return "bool"
	}
	if strings.Contains(pEntryType, "double") {
		return "float64"
	}
	if strings.Contains(pEntryType, "date") || strings.Contains(pEntryType, "time without time zone") {
		return "int64"
	}
	if strings.Contains(pEntryType, "timestamp") {
		return "int64"
	}
	return "emptyType"
}

/**
*	Metodo encargado de validar los campos nullable en BBDD.
 */
func validateNullableField(pEntryField string) string {
	switch pEntryField {
	case "NO":
		return "false"
	case "YES":
		return "true"
	default:
		return "emptyType"
	}
}

/**
* Metodo encargado de convertir el nombre de las columnas de BBDD
* a CamelCase.
 */
func CamelCase(pEntry string) string {
	byteSrc := []byte(pEntry)
	chunks := camelingRegex.FindAll(byteSrc, -1)
	for idx, val := range chunks {
		if idx > 0 {
			chunks[idx] = bytes.Title(val)
		}
	}
	return string(bytes.Join(chunks, nil))
}

/**
* Metodo encargado de conectarse a la BBDD.
 */
func connectToDB(ds string) (*sql.DB, error) {
	if db, err := sql.Open("postgres", ds); err != nil {
		return nil, errors.New(err.Error())
	} else {
		db.SetMaxIdleConns(10)
		db.SetMaxOpenConns(40)
		return db, nil
	}
}

/**
* Metodo encargado de obtener la conexion a partir del nombre de la BBDD.
 */
func getDB(ds_name string) (*sql.DB, error) {

	if db, err := connectToDB(ds_name); err != nil {
		return nil, err
	} else {
		return db, nil
	}
}
