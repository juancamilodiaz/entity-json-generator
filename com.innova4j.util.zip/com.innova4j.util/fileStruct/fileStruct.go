package fileStruct

type Message struct {
	Entities []Entity `json:"entities"`
}
type Attribute struct {
	Name       string `json:"name"`
	Types      string `json:"type"`
	Namedb     string `json:"namedb"`
	Nullable   string `json:"nullable"`
	PrimaryKey string `json:"primaryKey"`
}

type Entity struct {
	Key          string      `json:"key"`
	Classname    string      `json:"classname"`
	Tablename    string      `json:"tablename"`
	Owner        string      `json:"owner"`
	Attributes   []Attribute `json:"attributes"`
	Dependencies []string    `json:"dependencies"`
}
